package Persistence;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;


public class ExpertManager {
    // creating an object of class "OracleConnection"
    OracleConnection conexion = null;
    
     // creating a PreparedStatement as an atribute for ExpertManager to use it in several methods
    PreparedStatement ps = null;
    

    /**
    * Implements operations over Expert table
    * @param c  OracleConnection
    */    
    public ExpertManager(OracleConnection c) {
      conexion = c;
    }
     /**
    * REturnn a list with all the experts with a nationality
    * @param country
    * @throws SQLException 
    * @return ArrayList<expert>
    */
    public ArrayList<Expert> expertListByCountry(String country) throws SQLException {
        Statement stmt= null;
        ArrayList<Expert> sol;
        try {
            stmt=conexion.conn.createStatement();
        } catch (SQLException e) {
            throw e;
        }
        // creting result set
        String sql= "select * from EXPERT WHERE COUNTRY = '"+country+"'";
        ResultSet resulSet=stmt.executeQuery(sql);
        //Iterating throught the result rows
        while (resulSet.next()) {            
            //accesin colum values by index or name 
            
            String name=resulSet.getString("NAME");
            name=resulSet.getString("2");
           // int population=resulSet.getInt("POPULATION");
            
           
           
            Expert temp=new Expert();
            temp.setCodEXPERT(name);
            temp.setSex(resulSet.getString("SEXS"));
            
        
            System.out.println("NAME" + name);
            //System.out.println("POPULATION" + population);
            
            //accesin colums values by index or name
            
         
            
        }
        
        
    }    
    /**
    * Check if the expert exists
    * @param codExpert
    * @throws SQLException si ocurre alguna anomalía
     */
    public boolean expertExists (String codExpert) throws SQLException {
        // TODO add code
        
    }
     /**
    * Insert a new Expert
    * @param exp
    * @throws SQLException 
     */
    public boolean insertaExperto(Expert exp) throws SQLException 
    {
        // TODO add code
        try{
        PreparedStatement ps = conexion.conn.prepareStatement("Insert into expert values (?,?,?,?,?)");
               
        ps.setString(1, exp.getName());
        ps.setString(2, exp.getName());
        ps.setString(3,exp.getCountry());
        ps.setString(4,exp.getSex());
        ps.setString(5, exp.getSpecialism());
        ps.executeUpdate();
       
       }
       catch (SQLException e1){
           System.out.println(e1.getMessage());
       }
       finally {
           return true;
       }
    }
}