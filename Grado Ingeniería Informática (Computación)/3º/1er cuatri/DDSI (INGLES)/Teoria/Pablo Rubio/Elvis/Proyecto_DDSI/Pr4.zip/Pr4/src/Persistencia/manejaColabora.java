package Persistencia;

import java.sql.CallableStatement;
import java.sql.SQLException;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import oracle.jdbc.OracleTypes;

public class manejaColabora {
    // Creamos un objeto de tipo "conexionOracle"
    conexionOracle conexion = null;
    
    // Creamos un PreparedStatement como atributo de la clase manejaExperto para
    // utilizarlo en los diferentes métodos
    PreparedStatement ps = null;
    
     /**
    * Implementa operaciones sobre la tabla COLABORA
    * @param c conexión con Oracle
    */
    public manejaColabora(conexionOracle c) {
        conexion = c;
    }
     /**
    * Comprueba si existe una colaboración en la tabla de COLABORA dado su código
    * @param codExperto, codCaso caso
    * @throws SQLException si ocurre alguna anomalía
    */
    public boolean existeColaboracion(String codExperto, String codCaso,String fecha) throws SQLException {
        ps = conexion.conn.prepareStatement("SELECT * FROM COLABORA WHERE CODEXPERTO = ? AND CODCASO = ? AND FECHA = ?");
        ps.setString(1, codExperto);
        ps.setString(2, codCaso);
        ps.setString(3, fecha);
        ResultSet rs;
        rs = ps.executeQuery();
        boolean existe = rs.next();
        ps.close();
        return existe;
    }
    
     /**
    * Inserta una colaboración en la tabla COLABORA
    * @param codExperto, codCaso caso
    * @throws SQLException si ocurre alguna anomalía
    */
    public void insertaColaboracion(colabora col) throws SQLException {
        ps = conexion.conn.prepareStatement("INSERT INTO COLABORA VALUES (?,?,?,?)");
        ps.setString(1,col.getCodExperto());
        ps.setString(2, col.getCodCaso());
        ps.setString(3,col.getFecha());
        ps.setString(4, col.getDescripcionColaboracion());
        ResultSet rs;
        rs = ps.executeQuery();
        ps.close();
        
    } 
    
    public ResultSet listaColaboradoresporCaso(String codCaso) throws SQLException{
        String getCursorSql = "{call pColaboradoresCaso(?,?)}";
        CallableStatement call = null;
        ResultSet rs = null;
        try{
            call = conexion.conn.prepareCall(getCursorSql);
            call.setString(1, codCaso);
            call.registerOutParameter(2, OracleTypes.CURSOR);
            call.executeUpdate();
            rs = (ResultSet)call.getObject(2);
        }catch(SQLException ex){
            System.out.println(ex.getMessage());
        }/*finally{
            if (rs != null){
                rs.close();
            }
            if (call != null){
                call.close();
            }
        }*/
        return rs;
    }
    
    public ArrayList<colabora> listaColaboraciones() throws SQLException {
        ps = conexion.conn.prepareStatement("SELECT * FROM COLABORA ORDER BY CODEXPERTO");
        ResultSet rs;
        rs = ps.executeQuery();
        ArrayList<colabora> colaboraciones = new ArrayList<colabora>();
        colabora c;
        while (rs.next()) {
            c = new colabora(rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4));
            colaboraciones.add(c);
        }
        ps.close();
        return colaboraciones;
    }
    
    public void eliminaColaboracion(String codExperto,String codCaso,String Fecha) throws SQLException{
        ps = conexion.conn.prepareStatement("DELETE FROM COLABORA WHERE CODEXPERTO = ? AND CODCASO = ? AND FECHA = ?");
        ps.setString(1,codExperto);
        ps.setString(2,codCaso);
        ps.setString(3,Fecha);
        ResultSet rs;
        rs = ps.executeQuery();
        ps.close();
    }
    
}
