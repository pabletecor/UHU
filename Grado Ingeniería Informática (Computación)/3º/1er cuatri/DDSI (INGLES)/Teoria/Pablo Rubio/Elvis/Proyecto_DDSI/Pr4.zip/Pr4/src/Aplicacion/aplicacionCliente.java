package Aplicacion;

import Persistencia.*;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;
;

import Persistencia.*;
import java.io.InputStreamReader;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;



public class aplicacionCliente {

    static conexionOracle co;

    public static void main(String[] args) {

        MenuPrincipal mp = new MenuPrincipal();
        
    }

    public static void ejercicio1() throws UnsupportedEncodingException {
        try {
            System.out.print("Introduce pais: ");
            Scanner sc = new Scanner(new InputStreamReader(System.in, "ISO-8859-1"));
            String pais = sc.nextLine();
            manejaExperto me = new manejaExperto(co);
            ArrayList<experto> expertos = new ArrayList<experto>();
            expertos = me.listaExpertosPorPais(pais);
            for (int i = 0; i < expertos.size(); i++) {
                System.out.println(expertos.get(i).getCodExperto() + " " + expertos.get(i).getNombre() + " "
                        + expertos.get(i).getEspecialidad() + " " + expertos.get(i).getSexo() + " " + expertos.get(i).getPais());
            }
        } catch (SQLException ex) {
            Logger.getLogger(aplicacionCliente.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

    public static void ejercicio2() throws UnsupportedEncodingException, SQLException {
        System.out.print("Introduce codigo del experto: ");
        Scanner sc = new Scanner(new InputStreamReader(System.in, "ISO-8859-1"));
        String codexp = sc.nextLine();
        manejaExperto me = new manejaExperto(co);
        if(me.existeExperto(codexp)){
            System.out.println("El experto existe.");
        }else{
            System.out.println("El experto no existe. Introduzcalo");
            experto exp =new experto();
            exp.setCodExperto(codexp);
            System.out.println("Introduzca su nombre: ");
            exp.setNombre(sc.nextLine());
            System.out.println("Introduzca el pais: ");
            exp.setPais(sc.nextLine());
            System.out.println("Introduce su sexo (M/F): ");
            exp.setSexo(sc.nextLine());
            System.out.println("Introduce su especialidad: ");
            exp.setEspecialidad(sc.nextLine());
            me.insertaExperto(exp);
        }
    }

    public static void ejercicio3() throws UnsupportedEncodingException, SQLException {
        System.out.print("Introduce codigo del experto: ");
        Scanner sc = new Scanner(new InputStreamReader(System.in, "ISO-8859-1"));
        String codexp = sc.nextLine();
        manejaExperto me = new manejaExperto(co);
        colabora col = new colabora();
        col.setCodExperto(codexp);
        if(me.existeExperto(codexp)){
            System.out.println("El experto existe.Se va a asignar este experto");
        }else{
            co.inicioTransaccion();
            System.out.println("Comienzo de la transaccion...");
            System.out.println("El experto no existe. Introduzcalo");
            experto exp =new experto();
            exp.setCodExperto(codexp);
            System.out.println("Introduzca su nombre: ");
            exp.setNombre(sc.nextLine());
            System.out.println("Introduzca el pais: ");
            exp.setPais(sc.nextLine());
            System.out.println("Introduce su sexo (M/F): ");
            exp.setSexo(sc.nextLine());
            System.out.println("Introduce su especialidad: ");
            exp.setEspecialidad(sc.nextLine());
            me.insertaExperto(exp);
            System.out.println("Confirmar transaccion(S/N): ");
            String opcion = sc.nextLine();
            while(opcion.compareTo("S")!=0 || opcion.compareTo("N")!=0){
                System.out.println("Confirmar transaccion(S/N): ");
            }
            if(opcion.compareTo("S")==0){
                co.finTransaccionCommit();
            }else{
                co.finTransaccionRollback();
            }
        }
        System.out.println("Introduce codigo del caso: ");
        String codc = sc.nextLine();
        manejaCaso mc = new manejaCaso(co);
        col.setCodcaso(codc);
        System.out.println(col.getCodCaso());
        if(mc.existeCaso(codc)){
            System.out.println("El caso existe.Se va a asignar este caso");
        }else{
            System.out.println("Comienzo de la transaccion...");
            System.out.println("El caso no existe. Introduzcalo");
            caso c =new caso();
            c.setCodCaso(codc);
            System.out.println("Introduzca su nombre: ");
            c.setNombre(sc.nextLine());
            System.out.println("Introduzca la fecha de inicio(xx/xx/xxxx): ");
            c.setFechaInicio(sc.nextLine());
            System.out.println("Introduzca la fecha de fin(xx/xx/xxxx): ");
            c.setFechaFin(sc.nextLine());
            mc.insertaCaso(c);
            System.out.println("Confirmar transaccion(S/N): ");
            String opcion = sc.nextLine();
            while(opcion.compareTo("S")!=0 || opcion.compareTo("N")!=0){
                System.out.println("Confirmar transaccion(S/N): ");
            }
            if(opcion.compareTo("S")==0){
                co.finTransaccionCommit();
            }else{
                co.finTransaccionRollback();
            }
        }
        System.out.println("Introduce descripcion de la colaboracion: ");
        col.setDescripcionColaboracion(sc.nextLine());
        System.out.println("Introduce fecha de la colaboracion(xx/xx/xxxx): ");
        col.setFecha(sc.nextLine());
        manejaColabora mcol = new manejaColabora(co);
        while(mcol.existeColaboracion(col.getCodExperto(),col.getCodCaso(),col.getFecha())){
            System.out.println("La colaboracion existe. Cambie la fecha: ");
            col.setFecha(sc.nextLine());
        }
        mcol.insertaColaboracion(col);
        System.out.println("Confirmar transaccion(S/N): ");
        String opcion = sc.nextLine();
        while(opcion.compareTo("S")!=0 || opcion.compareTo("N")!=0){
            System.out.println("Confirmar transaccion(S/N): ");
        }
        if(opcion.compareTo("S")==0){
            co.finTransaccionCommit();
        }else{
            co.finTransaccionRollback();
        }
        
    }
}
