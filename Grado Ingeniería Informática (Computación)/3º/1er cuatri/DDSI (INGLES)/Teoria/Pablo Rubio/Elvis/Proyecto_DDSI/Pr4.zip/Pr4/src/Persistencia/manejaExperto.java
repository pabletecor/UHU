package Persistencia;

import java.sql.*;
import java.util.ArrayList;

public class manejaExperto {

    // Se crea un objeto de tipo "conexionOracle"
    conexionOracle conexion = null;

    // Se crea el PreparedStatement como atributo de la clase manejaExperto para
    // utilizarlo en los diferentes métodos
    PreparedStatement ps = null;

    /**
     * Implementa operaciones sobre la tabla EXPERTO
     *
     * @param c conexión con Oracle
     */
    public manejaExperto(conexionOracle c) {
        conexion = c;
    }

    /**
     * Devuelve una lista con todos los expertos cuyo país se pase por parámetro
     *
     * @param pais
     * @throws SQLException si ocurre alguna anomalía
     * @return ArrayList<experto>
     */
    public ArrayList<experto> listaExpertosPorPais(String pais) throws SQLException {
        ps = conexion.conn.prepareStatement("SELECT * FROM EXPERTO WHERE pais = ?");
        ps.setString(1, pais);
        ResultSet rs;
        rs = ps.executeQuery();
        ArrayList<experto> expertos = new ArrayList<experto>();
        experto exp;
        while (rs.next()) {
            exp = new experto(rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5));
            expertos.add(exp);
        }
        ps.close();
        return expertos;
    }
    
    public ArrayList<experto> listaExpertos() throws SQLException {
        ps = conexion.conn.prepareStatement("SELECT * FROM EXPERTO ORDER BY CODEXPERTO");
        ResultSet rs;
        rs = ps.executeQuery();
        ArrayList<experto> expertos = new ArrayList<experto>();
        experto exp;
        while (rs.next()) {
            exp = new experto(rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5));
            expertos.add(exp);
        }
        ps.close();
        return expertos;
    }
    
    /**
     * Comprueba si existe un experto
     *
     * @param codExperto
     * @throws SQLException si ocurre alguna anomalía
     */
    public boolean existeExperto(String codExperto) throws SQLException {
        ps = conexion.conn.prepareStatement("SELECT * FROM EXPERTO WHERE CODEXPERTO = ?");
        ps.setString(1, codExperto);
        ResultSet rs;
        rs = ps.executeQuery();
        boolean existe = rs.next();
        ps.close();
        return existe;
    }

    /**
     * inserta un experto
     *
     * @param exp
     * @throws SQLException si ocurre alguna anomalía
     */
    public void insertaExperto(experto exp) throws SQLException {
        ps = conexion.conn.prepareStatement("INSERT INTO EXPERTO VALUES (?,?,?,?,?)");
        ps.setString(1,exp.getCodExperto());
        ps.setString(2, exp.getNombre());
        ps.setString(3,exp.getPais());
        ps.setString(4, exp.getSexo());
        ps.setString(5,exp.getEspecialidad());
        ResultSet rs;
        rs = ps.executeQuery();
        ps.close();
    }
    
    public int sexoExperto(String tiposexo) throws SQLException{
        CallableStatement cs = null;
        String sql = "{ ? = call fSexoExperto(?) }";
        cs = conexion.conn.prepareCall(sql);
        cs.setString(2,tiposexo);
        cs.registerOutParameter(1, Types.INTEGER);
        cs.executeUpdate();
        int resultado = cs.getInt(1);
        return resultado;
    }
    
    public void eliminaExperto(String codExperto) throws SQLException{
        ps = conexion.conn.prepareStatement("DELETE FROM EXPERTO WHERE CODEXPERTO = ?");
        ps.setString(1,codExperto);
        ResultSet rs;
        rs = ps.executeQuery();
        ps.close();
    }
    
}
