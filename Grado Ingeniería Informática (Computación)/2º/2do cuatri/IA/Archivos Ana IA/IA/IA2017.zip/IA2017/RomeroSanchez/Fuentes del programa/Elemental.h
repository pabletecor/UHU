#include <string>
#include <vector>
#include <iostream>
#include <string>
#include <fstream>
#include <iomanip>
#include <stdio.h>
#include <windows.h>
#include <ctime>  //para time
#include <cstdlib> // for srand, rand

using namespace std;
