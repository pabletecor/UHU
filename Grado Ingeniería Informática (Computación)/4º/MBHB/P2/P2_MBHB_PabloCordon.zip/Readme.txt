Para poder cargar las estaciones en un mapa se usará el repositorio de github geojson.io (http://geojson.io)

Una vez abierta la web, visualizar el resultado se hará pulsando el boton open situado arriba a la izquierda de la página, y subiendo el archivo .geojson facilitado.